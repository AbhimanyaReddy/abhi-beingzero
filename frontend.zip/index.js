const express = require('express')
const app = express()
const port = 7000
app.use(express.static('frontend'))
app.get('/', (req, res) => res.sendFile("C:/Users/abhim/Desktop/newone/frontend/HTML/index.html"))



app.listen(port, () => console.log(`Example app listening on port ${port}!`))